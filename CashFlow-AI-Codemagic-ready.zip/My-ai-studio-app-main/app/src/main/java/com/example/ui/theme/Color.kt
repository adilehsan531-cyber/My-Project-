package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Professional Navy / Sapphire Palette
val NavyPrimaryLight = Color(0xFF0061A4)
val NavyOnPrimaryLight = Color(0xFFFFFFFF)
val NavyPrimaryContainerLight = Color(0xFFD1E4FF)
val NavyOnPrimaryContainerLight = Color(0xFF001D33)

val NavyPrimaryDark = Color(0xFF9ECAFF)
val NavyOnPrimaryDark = Color(0xFF003258)
val NavyPrimaryContainerDark = Color(0xFF00497D)
val NavyOnPrimaryContainerDark = Color(0xFFD1E4FF)

// Secondary Slate Steel
val SlateSecondaryLight = Color(0xFF535F70)
val SlateOnSecondaryLight = Color(0xFFFFFFFF)
val SlateSecondaryContainerLight = Color(0xFFD7E3F7)
val SlateOnSecondaryContainerLight = Color(0xFF101C2B)

val SlateSecondaryDark = Color(0xFFBBC7DB)
val SlateOnSecondaryDark = Color(0xFF253140)
val SlateSecondaryContainerDark = Color(0xFF3B4858)
val SlateOnSecondaryContainerDark = Color(0xFFD7E3F7)

// Tertiary Warm Gold / Amber Accent
val AmberTertiaryLight = Color(0xFF765B00)
val AmberOnTertiaryLight = Color(0xFFFFFFFF)
val AmberTertiaryContainerLight = Color(0xFFFFDF94)
val AmberOnTertiaryContainerLight = Color(0xFF241A00)

val AmberTertiaryDark = Color(0xFFECC24A)
val AmberOnTertiaryDark = Color(0xFF3E2E00)
val AmberTertiaryContainerDark = Color(0xFF594400)
val AmberOnTertiaryContainerDark = Color(0xFFFFDF94)

// Background & Surface - Clean Professional Polish Canvas
val BackgroundLight = Color(0xFFF8F9FF)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F0F4)
val OnBackgroundLight = Color(0xFF191C1E)
val OnSurfaceLight = Color(0xFF191C1E)
val OnSurfaceVariantLight = Color(0xFF44474E)
val OutlineLight = Color(0xFFE1E2E9)

val BackgroundDark = Color(0xFF111418)
val SurfaceDark = Color(0xFF191C20)
val SurfaceVariantDark = Color(0xFF262A30)
val OnBackgroundDark = Color(0xFFE2E2E6)
val OnSurfaceDark = Color(0xFFE2E2E6)
val OnSurfaceVariantDark = Color(0xFFC4C7D0)
val OutlineDark = Color(0xFF44474E)

// Financial Semantic Colors (Professional Polish)
val IncomeGreen = Color(0xFF386A44)
val IncomeGreenContainer = Color(0xFFE8F3EB)
val ExpenseRed = Color(0xFFBA1A1A)
val ExpenseRedContainer = Color(0xFFFFDAD6)
val SavingsBlue = Color(0xFF0061A4)
val SavingsBlueContainer = Color(0xFFD1E4FF)
val WarningAmber = Color(0xFFB86200)

// Hero Card Gradients
val HeroGradientStart = Color(0xFF0061A4)
val HeroGradientEnd = Color(0xFF004374)
val HeroGradientDarkStart = Color(0xFF003E6B)
val HeroGradientDarkEnd = Color(0xFF002440)

