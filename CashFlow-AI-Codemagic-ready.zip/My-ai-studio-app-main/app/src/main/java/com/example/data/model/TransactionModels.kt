package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class TransactionType {
    INCOME,
    EXPENSE,
    SAVINGS
}

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val amount: Double,
    val type: TransactionType,
    val category: String,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = "",
    val paymentMethod: String = "Cash", // Cash, Bank, Card, Mobile Wallet (JazzCash/Easypaisa/SadaPay/GPay/ApplePay)
    val currency: String = "PKR"
)

@Entity(tableName = "savings_goals")
data class SavingsGoalEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val targetAmount: Double,
    val currentAmount: Double = 0.0,
    val targetDate: Long? = null,
    val category: String = "General",
    val colorHex: String = "#006C50"
)

@Entity(tableName = "budget_limits")
data class BudgetLimitEntity(
    @PrimaryKey
    val category: String,
    val monthlyLimit: Double
)

data class ParsedTransactionResult(
    val title: String,
    val amount: Double,
    val type: TransactionType,
    val category: String,
    val paymentMethod: String = "Cash",
    val notes: String = "",
    val rawText: String = "",
    val confidence: Float = 0.9f,
    val dateString: String = "Today",
    val structuredSummary: String = "",
    val savingsTip: String = ""
)

data class CategorySummary(
    val category: String,
    val totalAmount: Double,
    val percentage: Float,
    val count: Int,
    val type: TransactionType
)

data class CashFlowMetrics(
    val totalIncome: Double = 0.0,
    val totalExpense: Double = 0.0,
    val totalSavings: Double = 0.0,
    val netBalance: Double = 0.0,
    val todayIncome: Double = 0.0,
    val todayExpense: Double = 0.0,
    val todayRemainingCashFlow: Double = 0.0,
    val monthRemainingCashFlow: Double = 0.0,
    val savingsRatePercentage: Double = 0.0,
    val recommendedSavingsAmount: Double = 0.0
)

data class AiMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val parsedTransaction: ParsedTransactionResult? = null,
    val isOverspendingAlert: Boolean = false
)
