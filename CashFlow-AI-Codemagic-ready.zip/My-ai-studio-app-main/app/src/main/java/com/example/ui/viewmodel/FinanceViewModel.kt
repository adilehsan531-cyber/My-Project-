package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.BudgetLimitEntity
import com.example.data.model.CashFlowMetrics
import com.example.data.model.CategorySummary
import com.example.data.model.ParsedTransactionResult
import com.example.data.model.SavingsGoalEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.model.AiMessage
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.preferences.UserSettings
import com.example.data.repository.FinanceRepository
import com.example.domain.AiFinanceParser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class FinanceViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val preferencesRepository = UserPreferencesRepository(application)
    private val aiFinanceParser = AiFinanceParser()
    private val repository = FinanceRepository(
        transactionDao = database.transactionDao(),
        savingsGoalDao = database.savingsGoalDao(),
        budgetLimitDao = database.budgetLimitDao(),
        preferencesRepository = preferencesRepository,
        aiFinanceParser = aiFinanceParser
    )

    val transactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savingsGoals: StateFlow<List<SavingsGoalEntity>> = repository.allSavingsGoals
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val budgetLimits: StateFlow<List<BudgetLimitEntity>> = repository.allBudgetLimits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userSettings: StateFlow<UserSettings> = repository.userSettings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    val cashFlowMetrics: StateFlow<CashFlowMetrics> = repository.cashFlowMetrics
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CashFlowMetrics())

    val categorySummaries: StateFlow<List<CategorySummary>> = repository.categorySummaries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // AI Chat & Parsing States
    private val _aiMessages = MutableStateFlow<List<AiMessage>>(emptyList())
    val aiMessages: StateFlow<List<AiMessage>> = _aiMessages.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    private val _quickParsedResult = MutableStateFlow<ParsedTransactionResult?>(null)
    val quickParsedResult: StateFlow<ParsedTransactionResult?> = _quickParsedResult.asStateFlow()

    private val _isQuickAiParsing = MutableStateFlow(false)
    val isQuickAiParsing: StateFlow<Boolean> = _isQuickAiParsing.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFilter = MutableStateFlow("All") // All, Income, Expense, Savings
    val selectedFilter: StateFlow<String> = _selectedFilter.asStateFlow()

    // Calculated Overspending Warnings
    val overspendingAlerts: StateFlow<List<String>> = combine(
        transactions,
        budgetLimits,
        userSettings
    ) { txs, limits, settings ->
        val alerts = mutableListOf<String>()
        val cal = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val monthStart = cal.timeInMillis

        val monthlyExpenses = txs.filter { it.type == TransactionType.EXPENSE && it.timestamp >= monthStart }
            .groupBy { it.category }
            .mapValues { entry -> entry.value.sumOf { it.amount } }

        for (limit in limits) {
            val spent = monthlyExpenses[limit.category] ?: 0.0
            if (spent >= limit.monthlyLimit) {
                alerts.add("⚠️ Over budget on ${limit.category}! Spent ${settings.currencySymbol} ${spent.toInt()} of ${settings.currencySymbol} ${limit.monthlyLimit.toInt()} limit.")
            } else if (spent >= limit.monthlyLimit * 0.85) {
                alerts.add("⚡ Near limit on ${limit.category}: ${settings.currencySymbol} ${spent.toInt()} / ${settings.currencySymbol} ${limit.monthlyLimit.toInt()} (85%+ used).")
            }
        }
        alerts
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.populateSampleDataIfEmpty()
            // Add initial greeting from AI Assistant
            if (_aiMessages.value.isEmpty()) {
                _aiMessages.value = listOf(
                    AiMessage(
                        text = """
                            👋 **Hello! I am your AI Cash Flow & Personal Finance Copilot.**
                            
                            You can speak or type to me in **English, Roman Urdu, or Urdu**:
                            • *"Aj dukan ka saman laya 2500 ka cash pe"*
                            • *"Careem ride 450 card se"*
                            • *"Salary credited 120,000"*
                            • *"10000 bachat ki emergency fund k liye"*
                            
                            Ask me anytime to analyze your cash flow, review budget overspending, or suggest optimal savings ratios!
                            
                            💡 **Actionable Savings Tip**: Logging your transactions immediately after they occur cuts unplanned expenses by up to 20%.
                        """.trimIndent(),
                        isUser = false
                    )
                )
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedFilter(filter: String) {
        _selectedFilter.value = filter
    }

    fun parseQuickAiInput(input: String) {
        if (input.isBlank()) return
        viewModelScope.launch {
            _isQuickAiParsing.value = true
            val currentBalance = cashFlowMetrics.value.netBalance
            val currencySymbol = userSettings.value.currencySymbol
            val result = repository.parseWithAi(input, currentBalance, currencySymbol)
            _quickParsedResult.value = result
            _isQuickAiParsing.value = false
        }
    }

    fun clearQuickParsedResult() {
        _quickParsedResult.value = null
    }

    fun confirmQuickParsedTransaction(result: ParsedTransactionResult) {
        viewModelScope.launch {
            val currency = userSettings.value.currencyCode
            val entity = TransactionEntity(
                title = result.title,
                amount = result.amount,
                type = result.type,
                category = result.category,
                notes = result.notes,
                paymentMethod = result.paymentMethod,
                currency = currency,
                timestamp = System.currentTimeMillis()
            )
            repository.insertTransaction(entity)
            _quickParsedResult.value = null

            // Add notification message to AI assistant history
            val newAiMessage = AiMessage(
                text = """
                    ✅ **Transaction Recorded Successfully!**
                    ${result.structuredSummary}
                    
                    ${result.savingsTip}
                """.trimIndent(),
                isUser = false,
                parsedTransaction = result
            )
            _aiMessages.value = _aiMessages.value + newAiMessage
        }
    }

    fun sendAiChatQuery(prompt: String) {
        if (prompt.isBlank()) return
        viewModelScope.launch {
            val userMsg = AiMessage(text = prompt, isUser = true)
            _aiMessages.value = _aiMessages.value + userMsg
            _isAiLoading.value = true

            val metrics = cashFlowMetrics.value
            val settings = userSettings.value
            val limits = budgetLimits.value
            val goals = savingsGoals.value

            val contextBuilder = StringBuilder()
            contextBuilder.append("Current Net Balance: ${settings.currencySymbol} ${metrics.netBalance}\n")
            contextBuilder.append("Total Income: ${settings.currencySymbol} ${metrics.totalIncome}\n")
            contextBuilder.append("Total Expense: ${settings.currencySymbol} ${metrics.totalExpense}\n")
            contextBuilder.append("Total Savings: ${settings.currencySymbol} ${metrics.totalSavings} (Savings Rate: ${String.format(Locale.getDefault(), "%.1f", metrics.savingsRatePercentage)}%)\n")
            contextBuilder.append("Today's Remaining Cash Flow: ${settings.currencySymbol} ${metrics.todayRemainingCashFlow}\n")
            contextBuilder.append("Month's Remaining Cash Flow: ${settings.currencySymbol} ${metrics.monthRemainingCashFlow}\n")
            if (goals.isNotEmpty()) {
                contextBuilder.append("Savings Goals: " + goals.joinToString(", ") { "${it.title}: ${it.currentAmount}/${it.targetAmount}" } + "\n")
            }
            if (limits.isNotEmpty()) {
                contextBuilder.append("Budget Limits: " + limits.joinToString(", ") { "${it.category}: max ${it.monthlyLimit}" } + "\n")
            }

            val response = repository.askAiAdvisor(
                query = prompt,
                financialContext = contextBuilder.toString(),
                currencySymbol = settings.currencySymbol
            )

            val aiMsg = AiMessage(text = response, isUser = false)
            _aiMessages.value = _aiMessages.value + aiMsg
            _isAiLoading.value = false
        }
    }

    fun addTransaction(
        title: String,
        amount: Double,
        type: TransactionType,
        category: String,
        paymentMethod: String,
        notes: String,
        timestamp: Long = System.currentTimeMillis()
    ) {
        viewModelScope.launch {
            val entity = TransactionEntity(
                title = title,
                amount = amount,
                type = type,
                category = category,
                paymentMethod = paymentMethod,
                notes = notes,
                currency = userSettings.value.currencyCode,
                timestamp = timestamp
            )
            repository.insertTransaction(entity)
        }
    }

    fun updateTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.updateTransaction(transaction)
        }
    }

    fun deleteTransaction(transaction: TransactionEntity) {
        viewModelScope.launch {
            repository.deleteTransaction(transaction)
        }
    }

    fun deleteTransactionById(id: Long) {
        viewModelScope.launch {
            repository.deleteTransactionById(id)
        }
    }

    fun addSavingsGoal(title: String, targetAmount: Double, category: String, colorHex: String) {
        viewModelScope.launch {
            repository.insertSavingsGoal(
                SavingsGoalEntity(
                    title = title,
                    targetAmount = targetAmount,
                    category = category,
                    colorHex = colorHex
                )
            )
        }
    }

    fun updateSavingsGoal(goal: SavingsGoalEntity) {
        viewModelScope.launch {
            repository.updateSavingsGoal(goal)
        }
    }

    fun deleteSavingsGoal(goal: SavingsGoalEntity) {
        viewModelScope.launch {
            repository.deleteSavingsGoal(goal)
        }
    }

    fun depositToSavingsGoal(goalId: Long, amount: Double) {
        viewModelScope.launch {
            repository.depositToSavingsGoal(goalId, amount, userSettings.value.currencyCode)
        }
    }

    fun setBudgetLimit(category: String, limit: Double) {
        viewModelScope.launch {
            repository.setBudgetLimit(BudgetLimitEntity(category, limit))
        }
    }

    fun deleteBudgetLimit(category: String) {
        viewModelScope.launch {
            repository.deleteBudgetLimit(category)
        }
    }

    fun updateCurrency(code: String, symbol: String) {
        viewModelScope.launch {
            repository.updateCurrency(code, symbol)
        }
    }

    fun updateMonthlyIncome(income: Double) {
        viewModelScope.launch {
            repository.updateMonthlyIncome(income)
        }
    }

    fun updateSavingsTarget(percentage: Double) {
        viewModelScope.launch {
            repository.updateSavingsTarget(percentage)
        }
    }

    fun updateAlertsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            repository.updateAlertsEnabled(enabled)
        }
    }

    fun updateUserName(name: String) {
        viewModelScope.launch {
            repository.updateUserName(name)
        }
    }

    fun generateExportSummary(): String {
        val dateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        val settings = userSettings.value
        val metrics = cashFlowMetrics.value
        val txs = transactions.value

        val sb = StringBuilder()
        sb.append("📋 CASH FLOW & FINANCIAL STATEMENT\n")
        sb.append("Generated: ${dateFormat.format(Date())}\n")
        sb.append("--------------------------------------\n")
        sb.append("Net Balance: ${settings.currencySymbol} ${String.format(Locale.getDefault(), "%,.2f", metrics.netBalance)}\n")
        sb.append("Total Income: ${settings.currencySymbol} ${String.format(Locale.getDefault(), "%,.2f", metrics.totalIncome)}\n")
        sb.append("Total Expenses: ${settings.currencySymbol} ${String.format(Locale.getDefault(), "%,.2f", metrics.totalExpense)}\n")
        sb.append("Total Savings: ${settings.currencySymbol} ${String.format(Locale.getDefault(), "%,.2f", metrics.totalSavings)}\n")
        sb.append("Savings Rate: ${String.format(Locale.getDefault(), "%.1f", metrics.savingsRatePercentage)}%\n")
        sb.append("--------------------------------------\n")
        sb.append("TRANSACTION LOG (Date | Type | Category | Amount | Method):\n")
        for (tx in txs.take(50)) {
            val sign = if (tx.type == TransactionType.INCOME) "+" else "-"
            sb.append("• ${SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(Date(tx.timestamp))} | ${tx.type.name} | ${tx.category} | $sign${settings.currencySymbol}${tx.amount.toInt()} | ${tx.paymentMethod} | ${tx.title}\n")
        }
        sb.append("--------------------------------------\n")
        sb.append("💡 Actionable Tip: Maintain at least a 20% savings buffer to secure financial freedom.\n")
        return sb.toString()
    }
}
