package com.example.domain

import com.example.BuildConfig
import com.example.data.model.ParsedTransactionResult
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.remote.GeminiClient
import com.example.data.remote.GeminiContent
import com.example.data.remote.GeminiGenerationConfig
import com.example.data.remote.GeminiPart
import com.example.data.remote.GeminiRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AiFinanceParser {

    private val dateFormat = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    suspend fun parseTransaction(
        input: String,
        currentBalance: Double,
        currencySymbol: String
    ): ParsedTransactionResult = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val prompt = """
                    You are an expert AI Personal Finance & Cash Flow Assistant.
                    The user has provided a transaction log or expense/income/savings note.
                    The input can be in English, Roman Urdu (e.g., 'Aj dukan ka saman laya 2500 ka', 'Careem ka kiraya 450', 'Salary agayi 120000', '10000 bachat ki emergency fund k liye'), or Urdu.
                    
                    User Input: "$input"
                    Current Net Balance: $currencySymbol $currentBalance
                    
                    Return a strictly valid JSON object with the following keys (no markdown wrapping, no extra keys):
                    {
                      "title": "Short descriptive title of transaction (in English)",
                      "amount": 0.0,
                      "type": "EXPENSE" or "INCOME" or "SAVINGS",
                      "category": "Food" | "Transportation" | "Utilities" | "Bills" | "Entertainment" | "Business/Work" | "Savings" | "Cash In/Out" | "Healthcare" | "Shopping" | "Salary" | "Investment" | "Other",
                      "paymentMethod": "Cash" | "Bank Transfer" | "Card" | "Mobile Wallet",
                      "notes": "Brief context or details",
                      "confidence": 0.95,
                      "structuredSummary": "A concise structured breakdown in bullet points with Date, Type, Category, Amount, and Running Balance",
                      "savingsTip": "A quick 1-line actionable tip to help optimize savings related to this transaction or general habit."
                    }
                """.trimIndent()

                val request = GeminiRequest(
                    contents = listOf(
                        GeminiContent(
                            parts = listOf(GeminiPart(text = prompt)),
                            role = "user"
                        )
                    ),
                    systemInstruction = GeminiContent(
                        parts = listOf(
                            GeminiPart(
                                text = "You are a precise personal finance parser. Always output strictly valid JSON matching the requested schema. Understand English, Roman Urdu, and Urdu fluently."
                            )
                        )
                    ),
                    generationConfig = GeminiGenerationConfig(
                        temperature = 0.2f,
                        responseMimeType = "application/json"
                    )
                )

                val response = GeminiClient.service.generateContent(apiKey, request)
                val rawJson = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!rawJson.isNullOrBlank()) {
                    val cleanedJson = rawJson.trim()
                        .removePrefix("```json")
                        .removePrefix("```")
                        .removeSuffix("```")
                        .trim()

                    val json = JSONObject(cleanedJson)
                    val title = json.optString("title", "Transaction")
                    val amount = json.optDouble("amount", 0.0)
                    val typeStr = json.optString("type", "EXPENSE").uppercase()
                    val type = try {
                        TransactionType.valueOf(typeStr)
                    } catch (e: Exception) {
                        TransactionType.EXPENSE
                    }
                    val category = json.optString("category", "Other")
                    val paymentMethod = json.optString("paymentMethod", "Cash")
                    val notes = json.optString("notes", "")
                    val confidence = json.optDouble("confidence", 0.9).toFloat()

                    val runningBalance = when (type) {
                        TransactionType.INCOME -> currentBalance + amount
                        TransactionType.EXPENSE -> currentBalance - amount
                        TransactionType.SAVINGS -> currentBalance - amount
                    }

                    val structuredSummary = json.optString(
                        "structuredSummary",
                        """
                        • Date: ${dateFormat.format(Date())}
                        • Type: ${type.name.lowercase().replaceFirstChar { it.uppercase() }}
                        • Category: $category
                        • Amount: $currencySymbol $amount
                        • Running Balance: $currencySymbol $runningBalance
                        """.trimIndent()
                    )

                    val savingsTip = json.optString(
                        "savingsTip",
                        "💡 Tip: Review weekly recurring spending in $category to identify opportunities for extra savings."
                    )

                    return@withContext ParsedTransactionResult(
                        title = title,
                        amount = amount,
                        type = type,
                        category = category,
                        paymentMethod = paymentMethod,
                        notes = notes,
                        rawText = input,
                        confidence = confidence,
                        dateString = dateFormat.format(Date()),
                        structuredSummary = structuredSummary,
                        savingsTip = savingsTip
                    )
                }
            } catch (e: Exception) {
                // Fallback to local heuristic parser
            }
        }

        // Fallback Local NLP Heuristic Parser
        fallbackParse(input, currentBalance, currencySymbol)
    }

    private fun fallbackParse(
        input: String,
        currentBalance: Double,
        currencySymbol: String
    ): ParsedTransactionResult {
        val lower = input.lowercase(Locale.getDefault())

        // Extract amount: numbers with optional decimals or commas
        val amountRegex = Regex("""(?:rs\.?|pkr|\$|€|£|₹)?\s*(\d+(?:[.,]\d+)?)""")
        val match = amountRegex.find(lower)
        val amount = match?.groupValues?.get(1)?.replace(",", "")?.toDoubleOrNull() ?: 0.0

        // Detect Type
        val isIncome = lower.contains("salary") || lower.contains("tankhwah") || lower.contains("income") ||
                lower.contains("credited") || lower.contains("wapis mila") || lower.contains("received") ||
                lower.contains("munafa") || lower.contains("profit") || lower.contains("kamayi") ||
                lower.contains("bonus") || lower.contains("cash in")

        val isSavings = lower.contains("saving") || lower.contains("bachat") || lower.contains("saved") ||
                lower.contains("emergency fund") || lower.contains("gold") || lower.contains("committee") ||
                lower.contains("invest") || lower.contains("deposit")

        val type = when {
            isIncome -> TransactionType.INCOME
            isSavings -> TransactionType.SAVINGS
            else -> TransactionType.EXPENSE
        }

        // Detect Category
        val category = when {
            isIncome && lower.contains("salary") -> "Salary"
            isIncome && lower.contains("invest") -> "Investment"
            isIncome -> "Income"
            isSavings -> "Savings"
            lower.contains("petrol") || lower.contains("fuel") || lower.contains("careem") ||
                    lower.contains("uber") || lower.contains("indrive") || lower.contains("bus") ||
                    lower.contains("taxi") || lower.contains("rickshaw") || lower.contains("ride") -> "Transportation"
            lower.contains("khana") || lower.contains("food") || lower.contains("lunch") ||
                    lower.contains("dinner") || lower.contains("breakfast") || lower.contains("nashta") ||
                    lower.contains("chai") || lower.contains("tea") || lower.contains("coffee") ||
                    lower.contains("burger") || lower.contains("pizza") || lower.contains("biryani") ||
                    lower.contains("restaurant") || lower.contains("hotel") -> "Food"
            lower.contains("grocery") || lower.contains("rashan") || lower.contains("sauda") ||
                    lower.contains("milk") || lower.contains("doodh") || lower.contains("sabzi") ||
                    lower.contains("mart") || lower.contains("market") || lower.contains("store") -> "Groceries"
            lower.contains("bill") || lower.contains("bijli") || lower.contains("electricity") ||
                    lower.contains("gas") || lower.contains("pani") || lower.contains("water") ||
                    lower.contains("wifi") || lower.contains("internet") || lower.contains("recharge") ||
                    lower.contains("mobile balance") -> "Bills"
            lower.contains("dukan") || lower.contains("business") || lower.contains("office") ||
                    lower.contains("client") || lower.contains("work") -> "Business/Work"
            lower.contains("doctor") || lower.contains("dawa") || lower.contains("medicine") ||
                    lower.contains("hospital") || lower.contains("clinic") || lower.contains("pharmacy") -> "Healthcare"
            lower.contains("kapre") || lower.contains("clothes") || lower.contains("shopping") ||
                    lower.contains("shoes") || lower.contains("daraz") || lower.contains("amazon") -> "Shopping"
            lower.contains("movie") || lower.contains("game") || lower.contains("netflix") ||
                    lower.contains("entertainment") || lower.contains("outing") -> "Entertainment"
            else -> "Other"
        }

        // Payment Method
        val paymentMethod = when {
            lower.contains("card") || lower.contains("visa") || lower.contains("mastercard") -> "Card"
            lower.contains("bank") || lower.contains("transfer") || lower.contains("online") -> "Bank Transfer"
            lower.contains("jazzcash") || lower.contains("easypaisa") || lower.contains("sadapay") ||
                    lower.contains("nayapay") || lower.contains("wallet") -> "Mobile Wallet"
            else -> "Cash"
        }

        // Title Cleanup
        var title = input.trim()
        if (title.length > 30) {
            title = "$category - $paymentMethod"
        }

        val runningBalance = when (type) {
            TransactionType.INCOME -> currentBalance + amount
            TransactionType.EXPENSE -> currentBalance - amount
            TransactionType.SAVINGS -> currentBalance - amount
        }

        val dateStr = dateFormat.format(Date())
        val structuredSummary = """
            • Date: $dateStr
            • Type: ${type.name.lowercase().replaceFirstChar { it.uppercase() }}
            • Category: $category
            • Amount: $currencySymbol $amount
            • Running Balance: $currencySymbol $runningBalance
        """.trimIndent()

        val savingsTip = when (type) {
            TransactionType.EXPENSE -> "💡 Tip: Setting a weekly limit on $category can free up 10-15% more for your savings goals."
            TransactionType.INCOME -> "💡 Tip: Allocate at least 20% of this inflow directly to your emergency fund or savings goal right away."
            TransactionType.SAVINGS -> "💡 Tip: Great consistency! Keeping your savings in a separate dedicated bucket prevents accidental spending."
        }

        return ParsedTransactionResult(
            title = title,
            amount = amount,
            type = type,
            category = category,
            paymentMethod = paymentMethod,
            notes = input,
            rawText = input,
            confidence = 0.85f,
            dateString = dateStr,
            structuredSummary = structuredSummary,
            savingsTip = savingsTip
        )
    }

    suspend fun askFinancialAdvisor(
        query: String,
        financialContext: String,
        currencySymbol: String
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY") {
            try {
                val prompt = """
                    You are an expert AI Personal Finance & Cash Flow Assistant embedded in a mobile finance application.
                    Your primary role is to help the user record, categorize, track, and analyze their daily expenses, income, cash flow, and savings accurately.
                    
                    User Query / Voice Note / Summary Request:
                    "$query"
                    
                    Current Financial Context of User:
                    $financialContext
                    
                    Behavior & Tone Guidelines:
                    1. Tone: Professional, structured, encouraging, and crystal clear.
                    2. Language: Accept user inputs in Roman Urdu, Urdu, or English. Respond in a friendly, easily readable format (English or Roman Urdu if addressed in Roman Urdu).
                    3. Structure: Always format financial logs or reviews with clear structured bullet points or clean markdown tables including: Date, Type (Income/Expense/Savings), Category, Amount, and Running Balance.
                    4. Analytical Insights & Warnings: Highlight overspending if categories exceed reasonable limits or user-set budgets. Advise on optimal saving percentages based on user income (e.g. 50/30/20 rule or tailored ratio).
                    5. Mandatory Closing: ALWAYS end the summary/response with a quick 1-line actionable tip to help optimize savings (e.g., '💡 Actionable Savings Tip: ...').
                """.trimIndent()

                val request = GeminiRequest(
                    contents = listOf(
                        GeminiContent(
                            parts = listOf(GeminiPart(text = prompt)),
                            role = "user"
                        )
                    ),
                    systemInstruction = GeminiContent(
                        parts = listOf(
                            GeminiPart(
                                text = "You are a professional AI Personal Finance & Cash Flow Assistant. Always provide structured breakdowns with bullet points or tables, calculate running balance / cash flow impacts accurately, and end every response with a 1-line actionable savings tip."
                            )
                        )
                    ),
                    generationConfig = GeminiGenerationConfig(
                        temperature = 0.4f
                    )
                )

                val response = GeminiClient.service.generateContent(apiKey, request)
                val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!text.isNullOrBlank()) {
                    return@withContext text.trim()
                }
            } catch (e: Exception) {
                // Fallback response
            }
        }

        // Heuristic fallback response
        generateFallbackAdvice(query, financialContext, currencySymbol)
    }

    private fun generateFallbackAdvice(
        query: String,
        financialContext: String,
        currencySymbol: String
    ): String {
        val lower = query.lowercase(Locale.getDefault())
        return when {
            lower.contains("saving") || lower.contains("bachat") || lower.contains("how much") -> """
                ### 💰 AI Savings & Allocation Recommendation
                
                Based on sound financial planning (50/30/20 Rule):
                - **50% Needs**: Essential bills, rent, groceries, utilities, transportation.
                - **30% Wants**: Dining out, entertainment, shopping, leisure.
                - **20% Savings & Debt**: Dedicated savings goals, emergency fund, investments.
                
                $financialContext
                
                💡 **Actionable Savings Tip**: Automate transferring 15-20% of your income into your dedicated savings account on the day you receive it to prevent lifestyle creep.
            """.trimIndent()

            lower.contains("overspend") || lower.contains("kharcha") || lower.contains("warning") -> """
                ### ⚠️ Cash Flow & Spending Analysis
                
                $financialContext
                
                - **Cash Flow Status**: Monitor your remaining daily limit to avoid dipping into essential reserves.
                - **High Velocity Categories**: Review non-essential daily micro-expenses (snacks, impulse delivery, rides).
                
                💡 **Actionable Savings Tip**: Implement the '24-hour rule' before making any non-essential purchase over $currencySymbol 1,000 to drastically cut impulse spending.
            """.trimIndent()

            else -> """
                ### 📊 Cash Flow & Financial Overview
                
                $financialContext
                
                • **Status**: All transactions are synchronized in your ledger.
                • **Cash Flow Health**: Keep your outflow beneath total income to maintain a positive net cash flow margin.
                
                💡 **Actionable Savings Tip**: Track every micro-transaction daily—users who log in real-time save an average of 18% more each month.
            """.trimIndent()
        }
    }
}
