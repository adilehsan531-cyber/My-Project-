package com.example.data.repository

import com.example.data.local.BudgetLimitDao
import com.example.data.local.SavingsGoalDao
import com.example.data.local.TransactionDao
import com.example.data.model.BudgetLimitEntity
import com.example.data.model.CashFlowMetrics
import com.example.data.model.CategorySummary
import com.example.data.model.ParsedTransactionResult
import com.example.data.model.SavingsGoalEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.TransactionType
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.preferences.UserSettings
import com.example.domain.AiFinanceParser
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import java.util.Calendar

class FinanceRepository(
    private val transactionDao: TransactionDao,
    private val savingsGoalDao: SavingsGoalDao,
    private val budgetLimitDao: BudgetLimitDao,
    private val preferencesRepository: UserPreferencesRepository,
    private val aiFinanceParser: AiFinanceParser
) {
    val allTransactions: Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    val allSavingsGoals: Flow<List<SavingsGoalEntity>> = savingsGoalDao.getAllGoals()
    val allBudgetLimits: Flow<List<BudgetLimitEntity>> = budgetLimitDao.getAllLimits()
    val userSettings: Flow<UserSettings> = preferencesRepository.userSettingsFlow

    val cashFlowMetrics: Flow<CashFlowMetrics> = combine(
        allTransactions,
        userSettings
    ) { transactions, settings ->
        calculateMetrics(transactions, settings)
    }

    val categorySummaries: Flow<List<CategorySummary>> = allTransactions.combine(userSettings) { transactions, _ ->
        calculateCategorySummaries(transactions)
    }

    private fun calculateMetrics(
        transactions: List<TransactionEntity>,
        settings: UserSettings
    ): CashFlowMetrics {
        var totalIncome = 0.0
        var totalExpense = 0.0
        var totalSavings = 0.0

        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val todayStart = calendar.timeInMillis

        var todayIncome = 0.0
        var todayExpense = 0.0

        // Start of month
        calendar.set(Calendar.DAY_OF_MONTH, 1)
        val monthStart = calendar.timeInMillis

        var monthIncome = 0.0
        var monthExpense = 0.0

        for (tx in transactions) {
            when (tx.type) {
                TransactionType.INCOME -> {
                    totalIncome += tx.amount
                    if (tx.timestamp >= todayStart) todayIncome += tx.amount
                    if (tx.timestamp >= monthStart) monthIncome += tx.amount
                }
                TransactionType.EXPENSE -> {
                    totalExpense += tx.amount
                    if (tx.timestamp >= todayStart) todayExpense += tx.amount
                    if (tx.timestamp >= monthStart) monthExpense += tx.amount
                }
                TransactionType.SAVINGS -> {
                    totalSavings += tx.amount
                }
            }
        }

        // Net Balance = Total Income - Total Expense - Total Savings (or Cash remaining)
        val netBalance = totalIncome - totalExpense - totalSavings
        val todayRemaining = todayIncome - todayExpense
        val monthRemaining = (if (settings.monthlyIncome > 0) settings.monthlyIncome else monthIncome) - monthExpense

        val effectiveIncome = if (settings.monthlyIncome > 0) settings.monthlyIncome else totalIncome
        val savingsRate = if (effectiveIncome > 0) (totalSavings / effectiveIncome) * 100.0 else 0.0
        val recommendedSavings = effectiveIncome * (settings.savingsTargetPercentage / 100.0)

        return CashFlowMetrics(
            totalIncome = totalIncome,
            totalExpense = totalExpense,
            totalSavings = totalSavings,
            netBalance = netBalance,
            todayIncome = todayIncome,
            todayExpense = todayExpense,
            todayRemainingCashFlow = todayRemaining,
            monthRemainingCashFlow = monthRemaining,
            savingsRatePercentage = savingsRate,
            recommendedSavingsAmount = recommendedSavings
        )
    }

    private fun calculateCategorySummaries(transactions: List<TransactionEntity>): List<CategorySummary> {
        val expenseTx = transactions.filter { it.type == TransactionType.EXPENSE }
        val totalExpense = expenseTx.sumOf { it.amount }

        if (totalExpense == 0.0) return emptyList()

        return expenseTx.groupBy { it.category }
            .map { (cat, list) ->
                val sum = list.sumOf { it.amount }
                val pct = if (totalExpense > 0) (sum / totalExpense).toFloat() else 0f
                CategorySummary(
                    category = cat,
                    totalAmount = sum,
                    percentage = pct,
                    count = list.size,
                    type = TransactionType.EXPENSE
                )
            }
            .sortedByDescending { it.totalAmount }
    }

    suspend fun insertTransaction(transaction: TransactionEntity): Long {
        val id = transactionDao.insertTransaction(transaction)
        // If savings transaction and matching goal, update goal
        if (transaction.type == TransactionType.SAVINGS) {
            val goals = savingsGoalDao.getAllGoals().first()
            val match = goals.firstOrNull { it.title.equals(transaction.title, ignoreCase = true) || it.category.equals(transaction.category, ignoreCase = true) }
            if (match != null) {
                savingsGoalDao.updateGoal(match.copy(currentAmount = match.currentAmount + transaction.amount))
            }
        }
        return id
    }

    suspend fun updateTransaction(transaction: TransactionEntity) = transactionDao.updateTransaction(transaction)

    suspend fun deleteTransaction(transaction: TransactionEntity) = transactionDao.deleteTransaction(transaction)

    suspend fun deleteTransactionById(id: Long) = transactionDao.deleteById(id)

    suspend fun parseWithAi(input: String, currentBalance: Double, currencySymbol: String): ParsedTransactionResult {
        return aiFinanceParser.parseTransaction(input, currentBalance, currencySymbol)
    }

    suspend fun askAiAdvisor(query: String, financialContext: String, currencySymbol: String): String {
        return aiFinanceParser.askFinancialAdvisor(query, financialContext, currencySymbol)
    }

    suspend fun insertSavingsGoal(goal: SavingsGoalEntity) = savingsGoalDao.insertGoal(goal)

    suspend fun updateSavingsGoal(goal: SavingsGoalEntity) = savingsGoalDao.updateGoal(goal)

    suspend fun deleteSavingsGoal(goal: SavingsGoalEntity) = savingsGoalDao.deleteGoal(goal)

    suspend fun depositToSavingsGoal(goalId: Long, amount: Double, currency: String) {
        val goals = savingsGoalDao.getAllGoals().first()
        val goal = goals.firstOrNull { it.id == goalId } ?: return
        savingsGoalDao.updateGoal(goal.copy(currentAmount = goal.currentAmount + amount))
        // Log transaction
        transactionDao.insertTransaction(
            TransactionEntity(
                title = "Savings Deposit: ${goal.title}",
                amount = amount,
                type = TransactionType.SAVINGS,
                category = "Savings",
                paymentMethod = "Bank Transfer",
                currency = currency,
                notes = "Contributed to goal: ${goal.title}"
            )
        )
    }

    suspend fun setBudgetLimit(limit: BudgetLimitEntity) = budgetLimitDao.insertOrUpdate(limit)

    suspend fun deleteBudgetLimit(category: String) = budgetLimitDao.deleteByCategory(category)

    suspend fun updateCurrency(code: String, symbol: String) = preferencesRepository.updateCurrency(code, symbol)

    suspend fun updateMonthlyIncome(income: Double) = preferencesRepository.updateMonthlyIncome(income)

    suspend fun updateSavingsTarget(percentage: Double) = preferencesRepository.updateSavingsTarget(percentage)

    suspend fun updateAlertsEnabled(enabled: Boolean) = preferencesRepository.updateAlertsEnabled(enabled)

    suspend fun updateUserName(name: String) = preferencesRepository.updateUserName(name)

    suspend fun populateSampleDataIfEmpty() {
        val count = transactionDao.getAllTransactions().first().size
        if (count == 0) {
            val now = System.currentTimeMillis()
            val day = 86400000L
            val sampleTransactions = listOf(
                TransactionEntity(
                    title = "Monthly Salary Credited",
                    amount = 125000.0,
                    type = TransactionType.INCOME,
                    category = "Salary",
                    timestamp = now - (3 * day),
                    notes = "Direct bank payroll deposit",
                    paymentMethod = "Bank Transfer",
                    currency = "PKR"
                ),
                TransactionEntity(
                    title = "Supermarket Monthly Rashan",
                    amount = 18500.0,
                    type = TransactionType.EXPENSE,
                    category = "Groceries",
                    timestamp = now - (2 * day),
                    notes = "Monthly groceries and household items",
                    paymentMethod = "Card",
                    currency = "PKR"
                ),
                TransactionEntity(
                    title = "Electricity & Utility Bill",
                    amount = 9200.0,
                    type = TransactionType.EXPENSE,
                    category = "Bills",
                    timestamp = now - (2 * day),
                    notes = "Online bill payment",
                    paymentMethod = "Mobile Wallet",
                    currency = "PKR"
                ),
                TransactionEntity(
                    title = "Emergency Fund Contribution",
                    amount = 15000.0,
                    type = TransactionType.SAVINGS,
                    category = "Savings",
                    timestamp = now - (1 * day),
                    notes = "Monthly 12% automated savings allocation",
                    paymentMethod = "Bank Transfer",
                    currency = "PKR"
                ),
                TransactionEntity(
                    title = "Fuel & Petrol refill",
                    amount = 4500.0,
                    type = TransactionType.EXPENSE,
                    category = "Transportation",
                    timestamp = now - (12 * 3600000L),
                    notes = "Car tank fill-up",
                    paymentMethod = "Cash",
                    currency = "PKR"
                ),
                TransactionEntity(
                    title = "Family Dinner at BBQ Tonight",
                    amount = 3800.0,
                    type = TransactionType.EXPENSE,
                    category = "Food",
                    timestamp = now - (4 * 3600000L),
                    notes = "Dinner outing",
                    paymentMethod = "Card",
                    currency = "PKR"
                )
            )
            transactionDao.insertAll(sampleTransactions)

            val sampleGoals = listOf(
                SavingsGoalEntity(
                    title = "Emergency Fund",
                    targetAmount = 150000.0,
                    currentAmount = 45000.0,
                    category = "Emergency",
                    colorHex = "#006C50"
                ),
                SavingsGoalEntity(
                    title = "New Laptop / Work Setup",
                    targetAmount = 200000.0,
                    currentAmount = 80000.0,
                    category = "Gadgets",
                    colorHex = "#00687A"
                ),
                SavingsGoalEntity(
                    title = "Annual Family Vacation",
                    targetAmount = 100000.0,
                    currentAmount = 35000.0,
                    category = "Travel",
                    colorHex = "#8B5000"
                )
            )
            for (g in sampleGoals) savingsGoalDao.insertGoal(g)

            val sampleLimits = listOf(
                BudgetLimitEntity(category = "Food", monthlyLimit = 15000.0),
                BudgetLimitEntity(category = "Groceries", monthlyLimit = 25000.0),
                BudgetLimitEntity(category = "Transportation", monthlyLimit = 10000.0),
                BudgetLimitEntity(category = "Bills", monthlyLimit = 15000.0),
                BudgetLimitEntity(category = "Shopping", monthlyLimit = 12000.0)
            )
            for (l in sampleLimits) budgetLimitDao.insertOrUpdate(l)

            preferencesRepository.updateMonthlyIncome(125000.0)
            preferencesRepository.updateSavingsTarget(20.0)
        }
    }
}
