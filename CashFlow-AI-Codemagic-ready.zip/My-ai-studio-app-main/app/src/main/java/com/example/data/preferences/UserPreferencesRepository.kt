package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

data class UserSettings(
    val currencyCode: String = "PKR",
    val currencySymbol: String = "Rs.",
    val monthlyIncome: Double = 0.0,
    val savingsTargetPercentage: Double = 20.0,
    val alertsEnabled: Boolean = true,
    val userName: String = "User"
)

class UserPreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val CURRENCY_CODE = stringPreferencesKey("currency_code")
        val CURRENCY_SYMBOL = stringPreferencesKey("currency_symbol")
        val MONTHLY_INCOME = doublePreferencesKey("monthly_income")
        val SAVINGS_TARGET_PERCENTAGE = doublePreferencesKey("savings_target_percentage")
        val ALERTS_ENABLED = booleanPreferencesKey("alerts_enabled")
        val USER_NAME = stringPreferencesKey("user_name")
    }

    val userSettingsFlow: Flow<UserSettings> = context.dataStore.data.map { preferences ->
        val currencyCode = preferences[PreferencesKeys.CURRENCY_CODE] ?: "PKR"
        val currencySymbol = preferences[PreferencesKeys.CURRENCY_SYMBOL] ?: "Rs."
        val monthlyIncome = preferences[PreferencesKeys.MONTHLY_INCOME] ?: 0.0
        val savingsTargetPercentage = preferences[PreferencesKeys.SAVINGS_TARGET_PERCENTAGE] ?: 20.0
        val alertsEnabled = preferences[PreferencesKeys.ALERTS_ENABLED] ?: true
        val userName = preferences[PreferencesKeys.USER_NAME] ?: "User"

        UserSettings(
            currencyCode = currencyCode,
            currencySymbol = currencySymbol,
            monthlyIncome = monthlyIncome,
            savingsTargetPercentage = savingsTargetPercentage,
            alertsEnabled = alertsEnabled,
            userName = userName
        )
    }

    suspend fun updateCurrency(code: String, symbol: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.CURRENCY_CODE] = code
            preferences[PreferencesKeys.CURRENCY_SYMBOL] = symbol
        }
    }

    suspend fun updateMonthlyIncome(income: Double) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.MONTHLY_INCOME] = income
        }
    }

    suspend fun updateSavingsTarget(percentage: Double) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.SAVINGS_TARGET_PERCENTAGE] = percentage
        }
    }

    suspend fun updateAlertsEnabled(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.ALERTS_ENABLED] = enabled
        }
    }

    suspend fun updateUserName(name: String) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.USER_NAME] = name
        }
    }
}
