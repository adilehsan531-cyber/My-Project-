package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.LocalAtm
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Work
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

object CategoryIconHelper {
    fun getIconForCategory(category: String): ImageVector {
        val lower = category.lowercase()
        return when {
            lower.contains("food") || lower.contains("dinner") || lower.contains("lunch") || lower.contains("restaurant") -> Icons.Default.Fastfood
            lower.contains("transport") || lower.contains("fuel") || lower.contains("petrol") || lower.contains("car") || lower.contains("ride") -> Icons.Default.DirectionsCar
            lower.contains("grocer") || lower.contains("rashan") || lower.contains("market") -> Icons.Default.ShoppingCart
            lower.contains("bill") || lower.contains("utilit") || lower.contains("electri") -> Icons.Default.Lightbulb
            lower.contains("salary") || lower.contains("income") || lower.contains("payroll") -> Icons.Default.AttachMoney
            lower.contains("saving") || lower.contains("bachat") || lower.contains("invest") -> Icons.Default.Savings
            lower.contains("business") || lower.contains("work") || lower.contains("office") -> Icons.Default.Work
            lower.contains("health") || lower.contains("doctor") || lower.contains("medic") -> Icons.Default.HealthAndSafety
            lower.contains("shop") || lower.contains("cloth") -> Icons.Default.ShoppingBag
            lower.contains("entertain") || lower.contains("movie") || lower.contains("game") -> Icons.Default.Movie
            lower.contains("school") || lower.contains("educat") || lower.contains("fee") -> Icons.Default.School
            lower.contains("home") || lower.contains("rent") -> Icons.Default.Home
            lower.contains("cash") -> Icons.Default.LocalAtm
            lower.contains("bank") -> Icons.Default.AccountBalance
            else -> Icons.Default.Category
        }
    }

    fun getColorForCategory(category: String): Color {
        val lower = category.lowercase()
        return when {
            lower.contains("food") -> Color(0xFFBA1A1A)
            lower.contains("transport") || lower.contains("fuel") -> Color(0xFF0061A4)
            lower.contains("grocer") -> Color(0xFF386A44)
            lower.contains("bill") || lower.contains("utilit") -> Color(0xFFB86200)
            lower.contains("salary") || lower.contains("income") -> Color(0xFF386A44)
            lower.contains("saving") || lower.contains("bachat") -> Color(0xFF0061A4)
            lower.contains("business") || lower.contains("work") -> Color(0xFF535F70)
            lower.contains("health") -> Color(0xFFBA1A1A)
            lower.contains("shop") -> Color(0xFF6750A4)
            lower.contains("entertain") -> Color(0xFFB86200)
            lower.contains("school") -> Color(0xFF0061A4)
            else -> Color(0xFF535F70)
        }
    }
}
