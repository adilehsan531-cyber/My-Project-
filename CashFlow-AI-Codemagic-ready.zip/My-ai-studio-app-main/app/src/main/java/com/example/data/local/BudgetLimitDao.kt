package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.BudgetLimitEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface BudgetLimitDao {
    @Query("SELECT * FROM budget_limits ORDER BY category ASC")
    fun getAllLimits(): Flow<List<BudgetLimitEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(limit: BudgetLimitEntity)

    @Update
    suspend fun update(limit: BudgetLimitEntity)

    @Delete
    suspend fun delete(limit: BudgetLimitEntity)

    @Query("DELETE FROM budget_limits WHERE category = :category")
    suspend fun deleteByCategory(category: String)
}
