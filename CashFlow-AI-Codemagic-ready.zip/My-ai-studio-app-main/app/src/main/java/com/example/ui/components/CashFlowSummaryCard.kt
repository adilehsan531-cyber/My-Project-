package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CashFlowMetrics
import com.example.ui.theme.HeroGradientEnd
import com.example.ui.theme.HeroGradientStart
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun CashFlowSummaryCard(
    metrics: CashFlowMetrics,
    currencySymbol: String,
    modifier: Modifier = Modifier
) {
    val monthName = SimpleDateFormat("MMMM", Locale.getDefault()).format(Date()).uppercase()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("cash_flow_summary_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            HeroGradientStart,
                            Color(0xFF004F87),
                            HeroGradientEnd
                        )
                    )
                )
                .padding(20.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header & Net Balance
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Net Cash Flow (Monthly)",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Medium
                        ),
                        color = Color.White.copy(alpha = 0.9f)
                    )

                    Surface(
                        color = Color(0x33FFFFFF),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = monthName,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                letterSpacing = 0.8.sp
                            ),
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "$currencySymbol ${String.format(Locale.getDefault(), "%,.2f", metrics.netBalance)}",
                    style = MaterialTheme.typography.displayMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 32.sp,
                        letterSpacing = (-0.5).sp
                    ),
                    color = Color.White
                )

                Spacer(modifier = Modifier.height(16.dp))

                HorizontalDivider(
                    color = Color(0x33FFFFFF),
                    thickness = 1.dp
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Breakdown: Income, Expense, Savings
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    MetricMiniItem(
                        title = "INCOME",
                        amount = "+${String.format(Locale.getDefault(), "%,.0f", metrics.totalIncome)}",
                        icon = Icons.Default.ArrowUpward,
                        iconColor = Color(0xFF81C784),
                        textColor = Color.White
                    )

                    MetricMiniItem(
                        title = "EXPENSES",
                        amount = "-${String.format(Locale.getDefault(), "%,.0f", metrics.totalExpense)}",
                        icon = Icons.Default.ArrowDownward,
                        iconColor = Color(0xFFFFB4AB),
                        textColor = Color(0xFFFFDAD6)
                    )

                    MetricMiniItem(
                        title = "SAVINGS (${metrics.savingsRatePercentage.toInt()}%)",
                        amount = "${String.format(Locale.getDefault(), "%,.0f", metrics.totalSavings)}",
                        icon = Icons.Default.Savings,
                        iconColor = Color(0xFFD1E4FF),
                        textColor = Color(0xFFD1E4FF)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Today & Monthly remaining cash flow strip
                Surface(
                    color = Color(0x24FFFFFF),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Today's Remaining Cash Flow",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Text(
                                text = "$currencySymbol ${String.format(Locale.getDefault(), "%,.0f", metrics.todayRemainingCashFlow)}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (metrics.todayRemainingCashFlow >= 0) Color(0xFFB5E5B9) else Color(0xFFFFB4AB)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "Month Remaining",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                            Text(
                                text = "$currencySymbol ${String.format(Locale.getDefault(), "%,.0f", metrics.monthRemainingCashFlow)}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (metrics.monthRemainingCashFlow >= 0) Color(0xFFB5E5B9) else Color(0xFFFFB4AB)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricMiniItem(
    title: String,
    amount: String,
    icon: ImageVector,
    iconColor: Color,
    textColor: Color
) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconColor,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    letterSpacing = 0.8.sp,
                    fontWeight = FontWeight.Medium
                ),
                color = Color.White.copy(alpha = 0.75f)
            )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = amount,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            color = textColor
        )
    }
}

