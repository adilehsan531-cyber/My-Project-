package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.data.model.CashFlowMetrics
import com.example.ui.components.CashFlowSummaryCard
import com.example.ui.theme.CashFlowAiTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun cashflow_card_screenshot() {
    composeTestRule.setContent {
      CashFlowAiTheme {
        CashFlowSummaryCard(
          metrics = CashFlowMetrics(
            totalIncome = 125000.0,
            totalExpense = 45000.0,
            totalSavings = 25000.0,
            netBalance = 55000.0,
            todayRemainingCashFlow = 2500.0,
            monthRemainingCashFlow = 55000.0,
            savingsRatePercentage = 20.0
          ),
          currencySymbol = "Rs."
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/cashflow_summary.png")
  }
}
