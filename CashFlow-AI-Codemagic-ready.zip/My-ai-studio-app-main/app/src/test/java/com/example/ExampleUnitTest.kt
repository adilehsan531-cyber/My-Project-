package com.example

import com.example.data.model.TransactionType
import com.example.domain.AiFinanceParser
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  private val parser = AiFinanceParser()

  @Test
  fun testRomanUrduExpenseParsing() = runBlocking {
    val result = parser.parseTransaction(
      input = "Aj dukan ka saman laya 2500 ka cash pe",
      currentBalance = 50000.0,
      currencySymbol = "Rs."
    )
    assertEquals(2500.0, result.amount, 0.01)
    assertEquals(TransactionType.EXPENSE, result.type)
    assertTrue(result.category.isNotEmpty())
    assertTrue(result.savingsTip.isNotBlank())
  }

  @Test
  fun testSalaryIncomeParsing() = runBlocking {
    val result = parser.parseTransaction(
      input = "Salary credited 120,000",
      currentBalance = 10000.0,
      currencySymbol = "Rs."
    )
    assertEquals(120000.0, result.amount, 0.01)
    assertEquals(TransactionType.INCOME, result.type)
    assertEquals("Salary", result.category)
  }

  @Test
  fun testSavingsGoalParsing() = runBlocking {
    val result = parser.parseTransaction(
      input = "10000 bachat ki emergency fund k liye",
      currentBalance = 80000.0,
      currencySymbol = "Rs."
    )
    assertEquals(10000.0, result.amount, 0.01)
    assertEquals(TransactionType.SAVINGS, result.type)
  }
}
