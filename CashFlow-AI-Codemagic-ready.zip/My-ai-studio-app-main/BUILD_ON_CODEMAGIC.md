# Build CashFlow AI APK with Codemagic

This project is prepared for an online Android build using Codemagic.

## What was changed
- Added `codemagic.yaml` for an Android debug APK build.
- The workflow downloads the project's required Gradle 9.3.1 on the Codemagic builder.
- Android SDK location is configured automatically.
- The debug build no longer depends on a missing local `debug.keystore`.
- `GEMINI_API_KEY` can be supplied as a Codemagic secret environment variable; it is never stored in this ZIP.

## Build steps
1. Create/sign in to a Codemagic account.
2. Put this project in a GitHub repository (or connect the repository directly if available).
3. In Codemagic, add the repository as an Android/native Android app.
4. Keep `codemagic.yaml` at the repository root.
5. Start the `cashflow-ai-debug` workflow.
6. Download the generated APK from the build's Artifacts section.

Codemagic's native Android workflow supports APK artifacts and uses `codemagic.yaml` at the repository root.

## Gemini key
If the app needs Gemini AI at runtime, add a Codemagic secret environment variable named `GEMINI_API_KEY`. The workflow creates `.env` during the build. Do not commit a real API key to GitHub.

## Release APK
The current workflow intentionally builds a debug APK because it does not require a personal Android signing key. For a Play Store/release APK, add an Android keystore to Codemagic and configure `KEYSTORE_PATH`, `STORE_PASSWORD`, `KEY_ALIAS`, and `KEY_PASSWORD` as secrets.
